# mymodule.py - This is the custom module

# Function with default parameter
def greet_with_default(name="Guest"):
    """Function with a default parameter."""
    print(f"Hello, {name}!")
